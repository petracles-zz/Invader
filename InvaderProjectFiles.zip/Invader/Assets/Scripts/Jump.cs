﻿using UnityEngine;
using System.Collections;

public class Jump : MonoBehaviour
{

		public string jumpButton = "Jump";
		public float jumpPower = 10.0f;
		public Animator anim;
		public bool grounded = false;
		public float minJumpDelay = 0.5f;
		public Transform groundCheck = GameObject.Find ("GameObject").transform;
		private float jumpTime = 0.0f;
		private bool jumped = false;
		
		public float groundDistance = 0.0f;
		RaycastHit hit;
		GameObject goPlayer;
		
		// Use this for initialization
		void Start ()
		{
				goPlayer = GameObject.Find ("player");
				anim = gameObject.GetComponent<Animator> ();
		}
		
		
	
		// Update is called once per frame
		void Update ()
		{
				
				groundCheck.transform.position = new Vector3 (goPlayer.transform.position.x,
						transform.position.y, transform.position.z);
		
				/*
				RaycastHit2D hit = Physics2D.Raycast (transform.position, -Vector2.up);
				if (hit != null) {
						float groundDistance = Mathf.Abs (hit.point.y - transform.position.y);
				}
				*/
		
				grounded = Physics2D.Linecast (transform.position, groundCheck.position);
				jumpTime -= Time.deltaTime;
				if (jumpTime < 0) {
						jumpTime = 0;
				}
				if (Input.GetButtonDown (jumpButton)) {
						jumped = true;
						grounded = false;
						anim.SetTrigger ("Jump");
						rigidbody2D.AddForce (transform.up * jumpPower);
						/*
						if (groundDistance < 2.25) {
								rigidbody2D.AddForce (transform.up * jumpPower);
						}
						*/
						jumpTime = minJumpDelay;
				}
				if (grounded && jumpTime <= 0 && jumped) {
						jumped = false;
						anim.SetTrigger ("Land");
				}
		}
}
